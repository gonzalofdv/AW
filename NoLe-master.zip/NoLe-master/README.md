# NoLe

Instrucciones de conexión:

Se facilita un archivo sql para crear la base de datos, uno para crear las tablas y uno para crear el usuario que realiza las conexiones. Todo ello dentro de la carpeta sql.
