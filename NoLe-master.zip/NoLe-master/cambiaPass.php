<h2>Cambiar contraseña</h2>
<div class="cambiaPass">
	<form class="formulario" action="procesarCambioPass.php" method="POST">
    <p><label>Contraseña actual: </label><input type="password" name="ant" required></p>
		<p><label>Nueva contraseña: </label><input type="password" name="pass" required></p>
    <p><label>Repetir nueva contraseña: </label><input type="password" name="pass2" required></p>
		<button type="submit">Enviar</button>
	</form>
</div>
