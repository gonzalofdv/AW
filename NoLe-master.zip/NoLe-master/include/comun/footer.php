<div class="footer">
	<p>&copy; Rodrigo Lagartera Peña - Alejandro Pascua Piña - Marcos Robles Palencia - Javier Picatoste Zangróniz - Manuel Oreja Valverde - Daniel Parra Rodríguez - Alberto Gutiérrez Gallego - Álvaro de la Cruz Casado
	</p>
</div>