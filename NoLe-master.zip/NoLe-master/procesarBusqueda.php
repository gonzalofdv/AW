<?php 

echo json_encode(urlencode($_POST["buscNom"]));

?>